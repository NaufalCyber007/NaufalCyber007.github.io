# Membuat Website Tour & Travel Sederhana
untuk folder asset yang berisikan gambar dan video, bisa didownload di link https://drive.google.com/file/d/1d6iabBfZWw5VblTLvrmSHslH_euOKIh4/view?usp=sharing
